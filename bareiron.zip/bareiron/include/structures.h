#ifndef H_STRUCTURES
#define H_STRUCTURES

void placeTreeStructure (short x, uint8_t y, short z);

#endif
